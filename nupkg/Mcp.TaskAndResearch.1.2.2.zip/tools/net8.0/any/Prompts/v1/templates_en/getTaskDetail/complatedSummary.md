**Completion Time:** {completedTime}

**Completion Summary:**

{summary}
