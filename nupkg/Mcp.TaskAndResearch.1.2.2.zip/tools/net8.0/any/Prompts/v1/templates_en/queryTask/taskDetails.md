### {taskName} (ID: {taskId})

- Status: {taskStatus}
- Description: {taskDescription}
- Creation Time: {createdAt}
