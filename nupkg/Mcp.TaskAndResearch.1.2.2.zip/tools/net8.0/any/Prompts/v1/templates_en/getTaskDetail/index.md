## Complete Task Details

### {name}

**ID:** `{id}`

**Status:** {status}

**Description:**{description}

{notesTemplate}

{dependenciesTemplate}

{implementationGuideTemplate}

{verificationCriteriaTemplate}

{relatedFilesTemplate}

**Creation Time:** {createdTime}

**Update Time:** {updatedTime}

{complatedSummaryTemplate}
