### Updated Task Details

- **Name:** {taskName}
- **Description:** {taskDescription}
  {taskNotes}
- **Status:** {taskStatus}
- **Update Time:** {taskUpdatedAt}

{filesContent}
