# Task Deletion Result

## {responseTitle}

{message}
