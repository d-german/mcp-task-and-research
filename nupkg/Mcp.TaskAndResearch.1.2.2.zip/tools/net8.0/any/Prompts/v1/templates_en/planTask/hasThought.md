**Step Two: Must forcibly use "process_thought" to think about the answer (prohibited from directly using analyze_task)**

1. **Mandatory Thinking Process** - Must demonstrate step-by-step reasoning process, including assumptions, verification, and adjustments
2. Warning: Must first use the "process_thought" tool to think, strictly prohibited from directly using analyze_task or answering directly
