## Task Complexity Assessment

- **Complexity Level:** {level}

{complexityStyle}

### Assessment Metrics

- Description Length: {descriptionLength} characters

- Number of Dependencies: {dependenciesCount}

### Processing Recommendations

{recommendation}
