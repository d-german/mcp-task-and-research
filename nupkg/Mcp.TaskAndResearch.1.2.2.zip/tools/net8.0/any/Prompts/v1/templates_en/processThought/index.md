## Thought {thoughtNumber}/{totalThoughts} - {stage}

{thought}

**Tags:** {tags}

**Principles Used:** {axioms_used}

**Assumptions Challenged:** {assumptions_challenged}

**Prohibitions:** You should prohibit all speculation, for any concerns please thoroughly review related code or use web search tools to query

{nextThoughtNeeded}
