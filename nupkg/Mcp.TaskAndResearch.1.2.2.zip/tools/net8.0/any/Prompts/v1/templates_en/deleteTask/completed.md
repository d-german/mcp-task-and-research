# Task Deletion Result

## Operation Denied

Task "{taskName}" (ID: `{taskId}`) has been completed. Deleting completed tasks is not allowed.
