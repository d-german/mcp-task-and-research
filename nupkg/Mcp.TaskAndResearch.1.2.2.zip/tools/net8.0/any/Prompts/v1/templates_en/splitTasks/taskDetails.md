### Task {index}: {name}

**ID:** `{id}`
**Description:** {description}

**Notes:** {notes}

**Implementation Guide:** {implementationGuide}

**Verification Criteria:** {verificationCriteria}

**Dependencies:** {dependencies}
