**Previous Research Results Summary:**

{previousState}

**Based on previous research, please note:**

- Avoid repeating content that has already been explored
- Deepen or expand based on previous research
- If you find information that conflicts with previous research, pay special attention and verify
