Search for tasks based on keywords or ID, display abbreviated task information
