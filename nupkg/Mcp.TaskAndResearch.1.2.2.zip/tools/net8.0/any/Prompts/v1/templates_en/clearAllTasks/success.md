# Clear All Tasks Result

## Operation Successful

All incomplete tasks have been cleared.{backupInfo}
