# Task Deletion Result

## System Error

Task with ID `{taskId}` could not be found. Please use the "list_tasks" tool to confirm valid task IDs and try again.
