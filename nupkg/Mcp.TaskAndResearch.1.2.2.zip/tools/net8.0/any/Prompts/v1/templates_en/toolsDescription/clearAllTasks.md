Clear incomplete tasks and reset the task list. This is a destructive operation that requires confirmation. Completed tasks will be backed up before clearing.
