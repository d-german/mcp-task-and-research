Retrieve complete detailed information of a task based on task ID, including untruncated implementation guides and verification criteria
