When you need to plan tasks or construct complex features, you can use this tool to receive task planning guidance. You are expected to strictly follow the step-by-step instructions provided by the tool when organizing your tasks. You may optionally choose to reference existing tasks for extended planning.

**Critical Warning**: All forms of `assumptions`, `guesses`, and `imagination` are strictly prohibited. You must use every `available tool` at your disposal to `gather real information`.
