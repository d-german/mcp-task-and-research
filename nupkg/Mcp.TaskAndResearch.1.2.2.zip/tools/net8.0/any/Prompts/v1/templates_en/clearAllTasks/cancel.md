# Clear All Tasks Result

## Operation Cancelled

The clearing operation was not confirmed. To clear all tasks, please set the confirm parameter to true.

⚠️ This operation will delete all incomplete tasks and cannot be undone.
