# Task Query Results

## No Matching Results

No tasks matching "{query}" were found.

### Possible Reasons:

- The task ID you provided does not exist or is incorrectly formatted
- The task may have been deleted
- The keyword spelling may be incorrect
- Try using shorter or similar keywords
- The task list may be empty

You can use the `list_tasks` command to view all existing tasks or use other keywords to search the history.
