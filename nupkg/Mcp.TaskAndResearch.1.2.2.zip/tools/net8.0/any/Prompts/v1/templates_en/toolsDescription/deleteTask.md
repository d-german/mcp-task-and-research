Delete incomplete tasks, but does not allow deleting completed tasks, ensuring the integrity of system records
